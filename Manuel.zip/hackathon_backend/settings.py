# settings.py
import os

USE_GCP = os.getenv("USE_GCP", "FALSE").upper() == "TRUE"

# Para futuro (cuando tengas Vertex / GCP):
PROJECT_ID = os.getenv("GOOGLE_CLOUD_PROJECT", "GR-HGNAI-016")
LOCATION = os.getenv("GOOGLE_CLOUD_LOCATION", "us-east4")

# Bucket futuro (cuando uses Storage):
MANUALS_BUCKET = os.getenv("MANUALS_BUCKET", f"manuals-docs-{PROJECT_ID.lower()}")
