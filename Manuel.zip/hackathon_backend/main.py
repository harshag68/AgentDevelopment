# main.py
import os
import nest_asyncio
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware   # 👈 IMPORTANTE
from pydantic import BaseModel

from google.genai import types
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService

from agents.manual_agent import create_manual_agent
from agents.data_agent import create_data_agent
from agents.search_agent import create_search_agent
from agents.generator_agent import create_generator_agent
from agents.coordinator import create_coordinator

from manual_store import init_db, save_manual, search_manuals, get_manual


from fastapi.middleware.cors import CORSMiddleware

# ---------------------------------------------------------
# 1) GOOGLE_API_KEY para ADK
# ---------------------------------------------------------
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
if not GOOGLE_API_KEY:
    raise RuntimeError("GOOGLE_API_KEY no está definido en el entorno")

# ADK usa esta env var internamente
os.environ["GOOGLE_API_KEY"] = GOOGLE_API_KEY

nest_asyncio.apply()
retry = types.HttpRetryOptions(attempts=5)

# ---------------------------------------------------------
# 2) Crear agentes individuales
# ---------------------------------------------------------
manual_agent    = create_manual_agent(retry)
data_agent      = create_data_agent(retry)
search_agent    = create_search_agent(retry)
generator_agent = create_generator_agent(retry)

# ---------------------------------------------------------
# 3) Coordinator multiagente
# ---------------------------------------------------------
coordinator = create_coordinator(
    manual_agent,
    data_agent,
    search_agent,
    generator_agent,
    retry,
)

# ---------------------------------------------------------
# 4) FastAPI app + CORS
# ---------------------------------------------------------
app = FastAPI()
init_db()  # 🔹 inicializa SQLite y la carpeta de docs

# Permitir llamadas desde cualquier origen (para usar HTML local, Copilot, etc.)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],      # en producción puedes restringir
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def root():
    return {
        "status": "ok",
        "message": "Backend multiagente funcionando!",
        "python": os.sys.executable,
    }

# ---------------------------------------------------------
# 5) Runner + sesiones
# ---------------------------------------------------------
session_service = InMemorySessionService()
app_name = "hackathon_app"
user_id = "user"  # demo

class AskPayload(BaseModel):
    question: str
class ManualStep(BaseModel):
    title: str
    description: str
    expected_output: str | None = None
    required_tools: str | None = None
    estimated_time_minutes: int | None = None
    is_critical: bool = False


class ManualCreate(BaseModel):
    title: str
    business_area: str | None = None
    requester: str | None = None
    created_by: str | None = None
    context: str | None = None
    requirements: str | None = None
    permissions: str | None = None
    outputs: str | None = None
    keywords: list[str] = []
    steps: list[ManualStep] = []

# ---------------------------------------------------------
# 6) Endpoint principal para el front
# ---------------------------------------------------------
@app.post("/ask")
async def ask(payload: AskPayload):
    session_id = "session_x"

    # 1) Obtener/crear sesión (OJO: métodos async)
    existing = await session_service.get_session(
        user_id=user_id,
        session_id=session_id,
        app_name=app_name,
    )
    if not existing:
        await session_service.create_session(
            user_id=user_id,
            session_id=session_id,
            app_name=app_name,
        )

    # 2) Runner
    runner = Runner(
        agent=coordinator,
        app_name=app_name,
        session_service=session_service,
    )

    # 3) Mensaje
    msg = types.Content(parts=[types.Part(text=payload.question)])
    final_text = ""

    # 4) Ejecutar agente
    async for event in runner.run_async(
        user_id=user_id,
        session_id=session_id,
        new_message=msg,
    ):
        if event.is_final_response() and event.content:
            for part in event.content.parts:
                if hasattr(part, "text") and part.text:
                    final_text += part.text

    return {"answer": final_text}
@app.post("/manuals")
def create_manual(manual: ManualCreate):
    manual_struct = manual.dict()
    manual_struct["steps"] = [s.dict() for s in manual.steps]
    manual_id = save_manual(manual_struct)
    return {"manual_id": manual_id}


@app.get("/manuals")
def list_manuals(q: str | None = None):
    if not q:
        q = ""
    results = search_manuals(q)
    return {"results": results}


@app.get("/manuals/{manual_id}")
def get_manual_detail(manual_id: str):
    manual = get_manual(manual_id)
    if not manual:
        return {"error": "Manual no encontrado"}
    return manual
