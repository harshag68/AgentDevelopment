# manual_store.py
import os
import sqlite3
import uuid
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(__file__), "manuals.db")
DOCS_DIR = os.path.join(os.path.dirname(__file__), "manual_docs")


def init_db():
    os.makedirs(DOCS_DIR, exist_ok=True)

    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    # Tabla diccionario de manuales
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS manuals_dict (
            manual_id       TEXT PRIMARY KEY,
            title           TEXT,
            business_area   TEXT,
            requester       TEXT,
            created_by      TEXT,
            created_at      TEXT,
            last_updated    TEXT,
            context         TEXT,
            requirements    TEXT,
            permissions     TEXT,
            outputs         TEXT,
            keywords        TEXT
        )
        """
    )

    # Tabla pasos
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS manual_steps (
            id                INTEGER PRIMARY KEY AUTOINCREMENT,
            manual_id         TEXT,
            step_number       INTEGER,
            step_title        TEXT,
            step_description  TEXT,
            expected_output   TEXT,
            required_tools    TEXT,
            estimated_time    INTEGER,
            is_critical       INTEGER
        )
        """
    )

    # Tabla archivos
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS manual_files (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            manual_id   TEXT,
            version     INTEGER,
            file_path   TEXT,
            format      TEXT,
            created_at  TEXT,
            created_by  TEXT
        )
        """
    )

    conn.commit()
    conn.close()


def _render_manual_html(manual_struct: dict) -> str:
    title = manual_struct.get("title", "Manual sin título")
    context = manual_struct.get("context", "")
    requirements = manual_struct.get("requirements", "")
    permissions = manual_struct.get("permissions", "")
    outputs = manual_struct.get("outputs", "")

    steps_html = ""
    for i, step in enumerate(manual_struct.get("steps", []), start=1):
        steps_html += f"""
        <h3>Paso {i}: {step.get('title','')}</h3>
        <p>{step.get('description','')}</p>
        <p><b>Resultado esperado:</b> {step.get('expected_output','')}</p>
        <hr/>
        """

    return f"""
    <html>
      <head>
        <meta charset="utf-8">
        <title>{title}</title>
      </head>
      <body>
        <h1>{title}</h1>
        <p><b>Contexto:</b> {context}</p>
        <p><b>Requisitos:</b> {requirements}</p>
        <p><b>Permisos necesarios:</b> {permissions}</p>
        <p><b>Entregables:</b> {outputs}</p>
        <hr/>
        {steps_html}
      </body>
    </html>
    """


def save_manual(manual_struct: dict) -> str:
    """
    manual_struct ejemplo:
    {
      "title": "...",
      "business_area": "...",
      "requester": "...",
      "created_by": "...",
      "context": "...",
      "requirements": "...",
      "permissions": "...",
      "outputs": "...",
      "keywords": ["kpi", "cierre mes"],
      "steps": [
         {
           "title": "...",
           "description": "...",
           "expected_output": "...",
           "required_tools": "...",
           "estimated_time_minutes": 10,
           "is_critical": true
         },
         ...
      ]
    }
    """
    manual_id = manual_struct.get("manual_id") or f"MAN-{uuid.uuid4().hex[:8]}"
    now = datetime.utcnow().isoformat()

    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    keywords = manual_struct.get("keywords", [])
    keywords_str = ",".join(keywords) if isinstance(keywords, list) else str(keywords)

    cur.execute(
        """
        INSERT OR REPLACE INTO manuals_dict (
          manual_id, title, business_area, requester, created_by,
          created_at, last_updated, context, requirements, permissions, outputs, keywords
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            manual_id,
            manual_struct.get("title"),
            manual_struct.get("business_area"),
            manual_struct.get("requester"),
            manual_struct.get("created_by"),
            now,
            now,
            manual_struct.get("context"),
            manual_struct.get("requirements"),
            manual_struct.get("permissions"),
            manual_struct.get("outputs"),
            keywords_str,
        ),
    )

    # Borrar pasos anteriores de ese manual (para actualizar)
    cur.execute("DELETE FROM manual_steps WHERE manual_id = ?", (manual_id,))

    step_rows = []
    for idx, step in enumerate(manual_struct.get("steps", []), start=1):
        step_rows.append(
            (
                manual_id,
                idx,
                step.get("title"),
                step.get("description"),
                step.get("expected_output"),
                step.get("required_tools"),
                step.get("estimated_time_minutes"),
                1 if step.get("is_critical", False) else 0,
            )
        )

    if step_rows:
        cur.executemany(
            """
            INSERT INTO manual_steps (
              manual_id, step_number, step_title, step_description,
              expected_output, required_tools, estimated_time, is_critical
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            step_rows,
        )

    # Generar HTML y guardar en disco
    html = _render_manual_html(manual_struct)
    file_name = f"{manual_id}_v1.html"
    file_path = os.path.join(DOCS_DIR, file_name)

    with open(file_path, "w", encoding="utf-8") as f:
        f.write(html)

    cur.execute(
        """
        INSERT INTO manual_files (
          manual_id, version, file_path, format, created_at, created_by
        ) VALUES (?, ?, ?, ?, ?, ?)
        """,
        (
            manual_id,
            1,
            file_path,
            "HTML",
            now,
            manual_struct.get("created_by"),
        ),
    )

    conn.commit()
    conn.close()

    return manual_id


def search_manuals(query: str, limit: int = 10) -> list[dict]:
    """
    Búsqueda súper simple por LIKE en título, contexto, outputs y keywords.
    """
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    like = f"%{query}%"
    cur.execute(
        """
        SELECT manual_id, title, business_area, context, keywords
        FROM manuals_dict
        WHERE
          title LIKE ?
          OR context LIKE ?
          OR outputs LIKE ?
          OR keywords LIKE ?
        ORDER BY last_updated DESC
        LIMIT ?
        """,
        (like, like, like, like, limit),
    )

    rows = cur.fetchall()
    conn.close()

    results = []
    for r in rows:
        results.append(
            {
                "manual_id": r[0],
                "title": r[1],
                "business_area": r[2],
                "context": r[3],
                "keywords": (r[4] or "").split(",") if r[4] else [],
            }
        )
    return results


def get_manual(manual_id: str) -> dict | None:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    cur.execute(
        """
        SELECT manual_id, title, business_area, requester, created_by,
               created_at, last_updated, context, requirements,
               permissions, outputs, keywords
        FROM manuals_dict
        WHERE manual_id = ?
        """,
        (manual_id,),
    )
    row = cur.fetchone()
    if not row:
        conn.close()
        return None

    manual = {
        "manual_id": row[0],
        "title": row[1],
        "business_area": row[2],
        "requester": row[3],
        "created_by": row[4],
        "created_at": row[5],
        "last_updated": row[6],
        "context": row[7],
        "requirements": row[8],
        "permissions": row[9],
        "outputs": row[10],
        "keywords": (row[11] or "").split(",") if row[11] else [],
        "steps": [],
        "files": [],
    }

    cur.execute(
        """
        SELECT step_number, step_title, step_description,
               expected_output, required_tools, estimated_time, is_critical
        FROM manual_steps
        WHERE manual_id = ?
        ORDER BY step_number
        """,
        (manual_id,),
    )
    for s in cur.fetchall():
        manual["steps"].append(
            {
                "step_number": s[0],
                "title": s[1],
                "description": s[2],
                "expected_output": s[3],
                "required_tools": s[4],
                "estimated_time_minutes": s[5],
                "is_critical": bool(s[6]),
            }
        )

    cur.execute(
        """
        SELECT version, file_path, format, created_at, created_by
        FROM manual_files
        WHERE manual_id = ?
        ORDER BY version DESC
        """,
        (manual_id,),
    )
    for f in cur.fetchall():
        manual["files"].append(
            {
                "version": f[0],
                "file_path": f[1],
                "format": f[2],
                "created_at": f[3],
                "created_by": f[4],
            }
        )

    conn.close()
    return manual
