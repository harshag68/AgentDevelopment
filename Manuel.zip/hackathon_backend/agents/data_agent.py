# agents/data_agent.py
from typing import Dict, Any, List
from google.adk.agents import LlmAgent
from google.genai import types

from manual_store import save_manual, search_manuals, get_manual


# ------------------------------------------------------------
# 1) TOOLS que usará el agente de datos
# ------------------------------------------------------------

def guardar_manual_tool(manual: Dict[str, Any]) -> Dict[str, Any]:
    """
    Guarda o actualiza un manual en la base local (SQLite) y genera el HTML.

    Args:
        manual: Diccionario con la estructura:
            {
              "title": "...",
              "business_area": "...",
              "requester": "...",
              "created_by": "...",
              "context": "...",
              "requirements": "...",
              "permissions": "...",
              "outputs": "...",
              "keywords": ["kpi", "cierre mes"],
              "steps": [
                 {
                   "title": "...",
                   "description": "...",
                   "expected_output": "...",
                   "required_tools": "...",
                   "estimated_time_minutes": 10,
                   "is_critical": true
                 },
                 ...
              ]
            }

    Returns:
        {
          "status": "ok",
          "manual_id": "MAN-xxxx",
          "title": "...",
          "file_path": "...",
          "steps_count": N
        }
    """
    manual_id = save_manual(manual)
    stored = get_manual(manual_id)

    # Para que lo veas en la consola del backend
    print("\n[DATA_AGENT] Manual guardado/actualizado:")
    print(f"  ID:    {manual_id}")
    print(f"  Título:{stored.get('title')}")
    print(f"  Area:  {stored.get('business_area')}")
    print(f"  Steps: {len(stored.get('steps', []))}")
    print("-------------------------------------------------\n")

    file_path = None
    files = stored.get("files", [])
    if files:
        # última versión
        file_path = files[0].get("file_path")

    return {
        "status": "ok",
        "manual_id": manual_id,
        "title": stored.get("title"),
        "file_path": file_path,
        "steps_count": len(stored.get("steps", [])),
    }


def buscar_manuales_tool(text_query: str, limit: int = 10) -> Dict[str, Any]:
    """
    Busca manuales por texto usando la tabla de diccionario.

    Args:
        text_query: Texto libre, por ejemplo 'cargar cubo datos python'.
        limit: Máximo de resultados a devolver.

    Returns:
        {
          "status": "ok",
          "results": [
             {
               "manual_id": "...",
               "title": "...",
               "business_area": "...",
               "context": "...",
               "keywords": [...]
             },
             ...
          ]
        }
    """
    results = search_manuals(text_query, limit=limit)

    print("\n[DATA_AGENT] Búsqueda de manuales:")
    print(f"  query: {text_query}")
    print(f"  encontrados: {len(results)}")
    for r in results:
        print(f"   - {r['manual_id']} | {r['title']} | {r['business_area']}")
    print("-------------------------------------------------\n")

    return {
        "status": "ok",
        "results": results,
    }


# ------------------------------------------------------------
# 2) Crear agente de datos
# ------------------------------------------------------------

def create_data_agent(retry: types.HttpRetryOptions) -> LlmAgent:
    """
    Crea el agente encargado de:
    - Recibir manuales ya estructurados (título, contexto, pasos, etc.).
    - Llamar al tool 'guardar_manual_tool' para persistirlos.
    - Usar 'buscar_manuales_tool' cuando deba encontrar manuales por contexto.
    """

    instruction = """
Eres el agente de DATOS de manuales.

Tu trabajo:
- Recibir desde otros agentes (por ejemplo el coordinador) la información de un manual.
- Convertir esa información a un diccionario con esta forma:

  {
    "title": "...",
    "business_area": "...",
    "requester": "...",
    "created_by": "...",
    "context": "...",
    "requirements": "...",
    "permissions": "...",
    "outputs": "...",
    "keywords": ["palabra1", "palabra2"],
    "steps": [
      {
        "title": "...",
        "description": "...",
        "expected_output": "...",
        "required_tools": "...",
        "estimated_time_minutes": 10,
        "is_critical": true
      },
      ...
    ]
  }

- Luego SIEMPRE llamar al tool `guardar_manual_tool(manual=...)` para guardar.
- Para buscar manuales por texto usa `buscar_manuales_tool(text_query=...)`.

Cuando termines de guardar, responde de forma breve indicando:
- manual_id
- título
- cantidad de pasos
    """

    agent = LlmAgent(
        name="data_agent",
        model="gemini-2.5-flash",
        instruction=instruction,
        tools=[guardar_manual_tool, buscar_manuales_tool],
    )
    return agent
